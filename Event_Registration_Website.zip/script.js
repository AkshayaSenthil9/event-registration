const form=document.getElementById('registrationForm');
const success=document.getElementById('successMessage');
const recordsEl=document.getElementById('records');
const countEl=document.getElementById('count');
const clearBtn=document.getElementById('clearData');
const key='campusConnectRegistrations';

function getRecords(){return JSON.parse(localStorage.getItem(key)||'[]')}
function renderRecords(){
  const data=getRecords(); countEl.textContent=data.length;
  if(!data.length){recordsEl.innerHTML='<p>No registrations yet. Submit the form to create a demo record.</p>';return}
  recordsEl.innerHTML=data.map((r,i)=>`<div class="record"><strong>${escapeHtml(r.name)}</strong> — ${escapeHtml(r.department)}, ${escapeHtml(r.year)}<br><small>${escapeHtml(r.email)} • ${escapeHtml(r.phone)} • ${escapeHtml(r.session)}</small></div>`).join('');
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function setError(id,msg){document.getElementById(id).textContent=msg}
form.addEventListener('submit',e=>{
  e.preventDefault();
  ['name','email','phone','department','year'].forEach(x=>setError(x+'Error',''));
  setError('agreeError',''); success.classList.remove('show'); success.textContent='';
  const name=document.getElementById('name').value.trim();
  const email=document.getElementById('email').value.trim();
  const phone=document.getElementById('phone').value.trim();
  const department=document.getElementById('department').value;
  const year=document.getElementById('year').value;
  const session=document.getElementById('session').value;
  const agree=document.getElementById('agree').checked;
  let ok=true;
  if(name.length<3){setError('nameError','Please enter your full name.');ok=false}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){setError('emailError','Enter a valid email address.');ok=false}
  if(!/^[0-9]{10}$/.test(phone)){setError('phoneError','Enter a valid 10-digit phone number.');ok=false}
  if(!department){setError('departmentError','Select your department.');ok=false}
  if(!year){setError('yearError','Select your year.');ok=false}
  if(!agree){setError('agreeError','Please confirm the information is correct.');ok=false}
  if(!ok)return;
  const data=getRecords();
  data.push({name,email,phone,department,year,session,registeredAt:new Date().toLocaleString()});
  localStorage.setItem(key,JSON.stringify(data));
  form.reset();
  success.textContent='Registration submitted successfully! Your demo record has been saved on this device.';
  success.classList.add('show');
  renderRecords();
  document.getElementById('records').scrollIntoView({behavior:'smooth',block:'center'});
});
clearBtn.addEventListener('click',()=>{if(confirm('Clear all demo registrations on this device?')){localStorage.removeItem(key);renderRecords();}});
renderRecords();
